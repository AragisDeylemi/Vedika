// Get the send button
const sendButton = document.getElementById("send-button");

// Add a click event listener to the send button
sendButton.addEventListener("click", function() {
  // Get the message from the message input field
  const message = document.getElementById("message-input").value;

  // Send the message to the background script
  chrome.runtime.sendMessage({type: "chatbot", message: message});
});
// Get the send button
const sendButton = document.getElementById("send-button");

// Add a click event listener to the send button
sendButton.addEventListener("click", function() {
  // Get the message from the message input field
  const message = document.getElementById("message-input").value;

  // Send the message to the background script
  chrome.runtime.sendMessage({type: "chatbot", message: message});
});

// Create a new div element for the chatbot response
const responseDiv = document.createElement("div");

// Set the ID of the response div
responseDiv.id = "chatbot-response";

// Add the response div to the document body
document.body.appendChild(responseDiv);

// Listen for messages from the background script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type === "chatbot") {
    // Get the response from the chatbot
    const response = request.response;

    // Display the response in the response div
    responseDiv.innerHTML = response;
  }
});