chrome.runtime.onInstalled.addListener(function() {
  console.log('Your plugin has been installed!');
});
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type === "chatbot") {
    // Send message to chatbot
    const message = request.message;
    const response = chatbot.getResponse(message);

    // Send response from chatbot
    sendResponse({response: response});
  }
});