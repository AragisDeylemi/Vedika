// Chatbot URL
const chatbotUrl = "https://poe.com/Vedika";

// Send message to chatbot
function sendMessage(message) {
  const xhr = new XMLHttpRequest();
  xhr.open("POST", chatbotUrl, true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.send(JSON.stringify({message: message}));
}

// Send message to background script
document.addEventListener("DOMContentLoaded", function() {
  sendMessage("Hello, I am Vedika.");
});